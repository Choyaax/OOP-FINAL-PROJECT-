/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.deliverysystem;

/**
 *
 * @author Craig
 */
public class DeliverySystem {

    public static void main(String[] args) {

    }
}
